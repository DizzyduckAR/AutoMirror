# Auto-Mirror
Big Update Auto-Mirror v0.3

**Added Full GUI with Multi mirror built in

**Added Control window name / Mirror Res / WIFI&USB /

**Added Auto-Grab Connected Phone Local IP and ADB connect in 1click

**Adeed Free clipper tool in one click

**Added Phone Lcd On/Off buttons

**Added One click button to update Server core

**Added No more console window

**Added New paypal for auto-mirror / patreon Icons

**Added New terminal command box to update user



![BotitCrop1](https://user-images.githubusercontent.com/52171360/65166947-4fa29180-da4a-11e9-8bba-c8ef3ae8cd62.png)


Youtube:
https://youtu.be/SA616OECdQU


Download:

**Mini need to run "Download Auto-Mirror" button before mirror

https://github.com/DizzyduckAR/AutoMirror/raw/master/Auto-Mirrorv0.3.zip


**Full Auto-Mirror V0.3 With scrcpy and Pre built

https://github.com/DizzyduckAR/AutoMirror/raw/master/AutoMirrorv3Full.zip





02/09/19 Added AutoMirror win7 fix for no powerShell systems.

20/08/19 Fixed IP.bat path error

**One click powershell AutoMirror any Android to PC By USB or WIFI**

**Auto Download scrcpy and ADB tools**

**Auto Get phone SN**

**Auto Put connected phone in TCP Mode**

**Auto Get phone IP**

**Auto Wifi Mirror**

--No Root needed--

--No Install needed--

--No Admin needed--

**Phone Debug !!MUST BE ON!!**

(Gif show how in: FULLAuto Mirror ZIP Help -DIR-)

Script can solo run from 3kb file

Simple run start file



**Download**

[AutoMirror MINI v0.2.zip](https://github.com/DizzyduckAR/AutoMirror/raw/master/AutoMirror%20MINI%20v0.2.zip) 




 
[AutoMirror Win7 No PS](https://github.com/DizzyduckAR/AutoMirror/raw/master/AutoMirror%20Win7-NOPS.zip)





**ScreenShots**



![1](https://user-images.githubusercontent.com/52171360/63218202-dbc94c80-c15e-11e9-9229-6c4cbb2e6881.png)

![2](https://user-images.githubusercontent.com/52171360/63218270-dd474480-c15f-11e9-863c-30ecf36b7d11.png)

![3](https://user-images.githubusercontent.com/52171360/63210222-688af080-c0f4-11e9-9221-e14699834c62.png)

![4](https://user-images.githubusercontent.com/52171360/63210224-6aed4a80-c0f4-11e9-934e-044cc4853b78.png)


**How to Debug Phone**

Step 1
![1Enable-Developer-Options-Android- GIF](https://user-images.githubusercontent.com/52171360/63210271-dafbd080-c0f4-11e9-8b32-18f4d4386272.gif)

Step 2
![2Enable-Debug-GIF](https://user-images.githubusercontent.com/52171360/63210272-dd5e2a80-c0f4-11e9-9849-f7254db6ff24.gif)

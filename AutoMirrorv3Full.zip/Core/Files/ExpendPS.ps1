﻿Expand-Archive scrcpy.zip -DestinationPath .\
Remove-Item –path scrcpy.zip